# Physical Core Optimizer — Skyrim SE / VR / LE

---

## 🇫🇷 Français

**Physical Core Optimizer** est un utilitaire open-source conçu pour Skyrim (SE, VR et Legendary Edition). Il force le jeu à n'utiliser que les cœurs physiques de votre processeur, en excluant les threads logiques liés au SMT ou à l'HyperThreading. Il applique également une priorité CPU `AboveNormal` pour réduire les micro-freezes, particulièrement sur les modpacks lourds.

**Comment ça fonctionne**

Le script lit la topologie réelle de votre CPU via l'API Windows native `GetLogicalProcessorInformationEx`, entièrement calculée en C# pour garantir une fiabilité maximale sur tous les processeurs. Il détecte automatiquement l'architecture : AMD Ryzen avec SMT, Intel classique avec HyperThreading, ou Intel hybride (12e génération et plus) avec ses P-cores hautes performances et ses E-cores efficaces. Une fois Skyrim lancé via SKSE, le masque d'affinité et la priorité sont appliqués sur le processus, avec jusqu'à 10 tentatives de vérification pour s'assurer que Windows n'a pas réinitialisé les paramètres.

**Versions de Skyrim supportées**

Le script supporte Skyrim Special Edition (`SkyrimSE.exe`), Skyrim VR (`SkyrimVR.exe`) et Skyrim Legendary Edition (`Skyrim.exe`). Pour changer de version, ouvrez `SetAffinity.ps1` et modifiez la première ligne : `$targetGame = "SkyrimSE"`.

**Installation**

Téléchargez l'archive de la dernière version, placez tous les fichiers dans le dossier racine de Skyrim (là où se trouve `SkyrimSE.exe`), puis lancez `Launch.bat` en tant qu'administrateur. Si vous utilisez Mod Organizer 2, ajoutez simplement `Launch.bat` comme exécutable dans MO2 et lancez-le depuis là.

**Comment vérifier que ça fonctionne**

Lancez Skyrim avec le script, puis ouvrez PowerShell en administrateur et tapez la commande suivante :

```powershell
Get-Process -Name SkyrimSE | Select-Object Name, Id, @{Name="ProcessorAffinity";Expression={($_.ProcessorAffinity).ToString("X")}}
```

Si le résultat affiche `FFFFFFFF`, l'optimisation n'a pas été appliquée. Si vous obtenez une valeur différente comme `55555555`, seuls les cœurs physiques sont utilisés et l'outil fonctionne correctement. La valeur exacte dépend de votre processeur.

**Compatibilité**

Cet outil est compatible avec ENB, ReShade, DXVK et tous les plugins SKSE. Il ne modifie aucun fichier du jeu et ne repose sur aucune DLL. Il est 100 % externe et open-source. Il est inutile de le combiner avec d'autres mods d'affinité CPU présents sur Nexus Mods, car ils remplissent le même rôle et leur cumul pourrait provoquer des conflits.

---

## 🇬🇧 English

**Physical Core Optimizer** is an open-source utility designed for Skyrim (SE, VR and Legendary Edition). It forces the game to use only the physical cores of your processor, excluding logical threads tied to SMT or HyperThreading. It also sets the CPU priority to `AboveNormal` to reduce micro-freezes, especially on heavy modpacks.

**How it works**

The script reads the real topology of your CPU via the native Windows API `GetLogicalProcessorInformationEx`, computed entirely in C# to ensure maximum reliability across all processors. It automatically detects the architecture: AMD Ryzen with SMT, classic Intel with HyperThreading, or hybrid Intel (12th generation and above) with its high-performance P-cores and efficiency E-cores. Once Skyrim is launched via SKSE, the affinity mask and priority are applied to the process, with up to 10 verification attempts to make sure Windows has not reset the settings.

**Supported Skyrim versions**

The script supports Skyrim Special Edition (`SkyrimSE.exe`), Skyrim VR (`SkyrimVR.exe`) and Skyrim Legendary Edition (`Skyrim.exe`). To switch version, open `SetAffinity.ps1` and edit the first line: `$targetGame = "SkyrimSE"`.

**Installation**

Download the latest release archive, place all files in your Skyrim root folder (where `SkyrimSE.exe` is located), then run `Launch.bat` as administrator. If you use Mod Organizer 2, simply add `Launch.bat` as an executable in MO2 and launch it from there.

**How to verify it works**

Launch Skyrim with the script, then open PowerShell as administrator and run the following command:

```powershell
Get-Process -Name SkyrimSE | Select-Object Name, Id, @{Name="ProcessorAffinity";Expression={($_.ProcessorAffinity).ToString("X")}}
```

If the result shows `FFFFFFFF`, the optimization was not applied. If you get a different value such as `55555555`, only physical cores are being used and the tool is working correctly. The exact value depends on your processor.

**Compatibility**

This tool is fully compatible with ENB, ReShade, DXVK and all SKSE plugins. It does not modify any game files and does not rely on any DLL. It is 100% external and open-source. There is no need to combine it with other CPU affinity mods from Nexus Mods, as they serve the same purpose and combining them may cause conflicts.

---

*Made with ❤️ by Snipy_Stream*
