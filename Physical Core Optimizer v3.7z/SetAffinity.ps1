# ==================================================
#  CONFIGURATION - modifie selon ta version de Skyrim
#  SkyrimSE  = Special Edition (default)
#  Skyrim    = Legendary Edition
#  SkyrimVR  = VR Edition
# ==================================================
$targetGame = "SkyrimSE"   # <-- change ici si besoin

$ErrorActionPreference = 'SilentlyContinue'

# ==================================================
#  DETECTION LANGUE (FR / EN / DE / ES)
# ==================================================
$lang = (Get-Culture).TwoLetterISOLanguageName

function T {
    param([string]$fr, [string]$en, [string]$de, [string]$es)
    switch($lang) {
        "fr" { return $fr }
        "de" { return $de }
        "es" { return $es }
        default { return $en }
    }
}

# ==================================================
#  FICHIER DE LOG
# ==================================================
$logFile = "$PSScriptRoot\Physical_Core_Optimizer.log"
function Log { param([string]$l,[string]$m) Add-Content -Path $logFile -Value "[$(Get-Date -Format 'HH:mm:ss')] [$l] $m" -Encoding UTF8 }
Set-Content -Path $logFile -Value "====================================================`n  Physical Core Optimizer - Par Snipy_Stream`n  $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')`n====================================================`n" -Encoding UTF8

# ==================================================
#  HELPERS AFFICHAGE
# ==================================================
$sep  = "  ===================================================="
$dash = "  ----------------------------------------------------"

function WC {
    param([string]$text, [System.ConsoleColor]$color = "Yellow")
    $inner  = 50
    $spaces = [math]::Max(0, [math]::Floor(($inner - $text.Length) / 2))
    Write-Host ("  " + (" " * $spaces) + $text) -ForegroundColor $color
}

function Spin {
    param([string]$label, [int]$ms = 900)
    $frames = @("|","/","-","\"); $e = 0; $s = 120
    $inner  = 50
    $spaces = [math]::Max(0, [math]::Floor(($inner - $label.Length) / 2))
    $prefix = "  " + (" " * $spaces)
    Write-Host -NoNewline "$prefix$label  " -ForegroundColor DarkYellow
    while($e -lt $ms) {
        foreach($f in $frames) {
            Write-Host -NoNewline "`b$f" -ForegroundColor Yellow
            Start-Sleep -Milliseconds $s; $e += $s
            if($e -ge $ms) { break }
        }
    }
    Write-Host "`b "
}

# ==================================================
#  C# - CALCUL MASQUE AFFINITE
# ==================================================
$cs = @"
using System; using System.Runtime.InteropServices; using System.Collections.Generic;
public class CpuTopology {
    const int RelationProcessorCore=0; const byte LTP_PC_SMT=1;
    [StructLayout(LayoutKind.Sequential)] struct GROUP_AFFINITY {
        public UIntPtr Mask; public ushort Group;
        [MarshalAs(UnmanagedType.ByValArray,SizeConst=3)] public ushort[] Reserved; }
    [StructLayout(LayoutKind.Sequential)] struct PROCESSOR_RELATIONSHIP {
        public byte Flags; public byte EfficiencyClass;
        [MarshalAs(UnmanagedType.ByValArray,SizeConst=20)] public byte[] Reserved;
        public ushort GroupCount; }
    [StructLayout(LayoutKind.Sequential)] struct SLPIX { public int Relationship; public uint Size; }
    [DllImport("kernel32.dll",SetLastError=true)]
    static extern bool GetLogicalProcessorInformationEx(int t,IntPtr b,ref uint l);
    struct CI { public ulong A,F; public byte E; public bool S; }
    public static long GetPhysicalCoreMask(out bool isHybrid,out int pC,out int eC,out bool hasSMT){
        isHybrid=false; pC=0; eC=0; hasSMT=false;
        uint len=0; GetLogicalProcessorInformationEx(RelationProcessorCore,IntPtr.Zero,ref len);
        IntPtr buf=Marshal.AllocHGlobal((int)len); var cores=new List<CI>();
        try {
            if(!GetLogicalProcessorInformationEx(RelationProcessorCore,buf,ref len)) return 0;
            IntPtr ptr=buf,end=IntPtr.Add(buf,(int)len);
            while(ptr.ToInt64()<end.ToInt64()){
                var h=Marshal.PtrToStructure<SLPIX>(ptr);
                if(h.Relationship==RelationProcessorCore){
                    var rel=Marshal.PtrToStructure<PROCESSOR_RELATIONSHIP>(IntPtr.Add(ptr,8));
                    var grp=Marshal.PtrToStructure<GROUP_AFFINITY>(IntPtr.Add(IntPtr.Add(ptr,8),24));
                    ulong m=grp.Mask.ToUInt64();
                    cores.Add(new CI{A=m,F=m&(ulong)(-(long)m),E=rel.EfficiencyClass,S=(rel.Flags&LTP_PC_SMT)!=0}); }
                ptr=IntPtr.Add(ptr,(int)h.Size); }
        } finally { Marshal.FreeHGlobal(buf); }
        byte mn=255,mx=0;
        foreach(var c in cores){ if(c.E<mn)mn=c.E; if(c.E>mx)mx=c.E; if(c.S)hasSMT=true; }
        isHybrid=(mn!=mx); ulong mask=0;
        if(isHybrid){ foreach(var c in cores){ if(c.E==mx){mask|=c.F;pC++;}else eC++; } }
        else { foreach(var c in cores){ mask|=(hasSMT?c.F:c.A); pC++; } }
        return (long)mask; }
}
"@
if(-not([System.Management.Automation.PSTypeName]'CpuTopology').Type){ Add-Type -TypeDefinition $cs -Language CSharp }

# ==================================================
#  DETECTION CPU
# ==================================================
Spin (T "Analyse du processeur..." "Analyzing processor..." "Prozessor wird analysiert..." "Analizando procesador...")
$cpu     = Get-CimInstance Win32_Processor
$cpuName = $cpu.Name.Trim()
$lc      = $cpu.NumberOfLogicalProcessors
$pc      = $cpu.NumberOfCores
WC (T "Nom du processeur detecte :" "Detected processor :" "Erkannter Prozessor :" "Procesador detectado :") Cyan
WC $cpuName White
WC (T "Logiques : $lc   |   Physiques : $pc" "Logical : $lc   |   Physical : $pc" "Logisch : $lc   |   Physisch : $pc" "Logicos : $lc   |   Fisicos : $pc") Cyan
Write-Host ""
Write-Host $dash -ForegroundColor DarkYellow
Log "INFO" "CPU:$cpuName Phys:$pc Log:$lc"

# ==================================================
#  CALCUL MASQUE
# ==================================================
Spin (T "Calcul du masque d'affinite..." "Computing affinity mask..." "Affinitaetsmaske wird berechnet..." "Calculando mascara de afinidad...")
$ih=$false; $pC=0; $eC=0; $hs=$false
$aml = [CpuTopology]::GetPhysicalCoreMask([ref]$ih,[ref]$pC,[ref]$eC,[ref]$hs)
$hex = ([Convert]::ToUInt64($aml)).ToString("X")

if($ih) {
    WC (T "Intel Hybride : P-cores=$pC  |  E-cores exclus=$eC" "Intel Hybrid : P-cores=$pC  |  E-cores excluded=$eC" "Intel Hybrid : P-Kerne=$pC  |  E-Kerne ausgeschl.=$eC" "Intel Hibrido : P-cores=$pC  |  E-cores excluidos=$eC") Magenta
    Log "INFO" "Hybrid P:$pC E:$eC"
} else {
    WC (T "Cores physiques utilises : $pC" "Physical cores used : $pC" "Physische Kerne genutzt : $pC" "Nucleos fisicos utilizados : $pC") DarkYellow
    Log "INFO" "Homogeneous SMT:$hs Cores:$pC"
}
Write-Host $dash -ForegroundColor DarkYellow
Log "INFO" "Mask:0x$hex"

# ==================================================
#  DETECTION DE LA VERSION DE SKYRIM
# ==================================================
# On cherche les executables dans l'ordre de priorite
$gameProcessNames = @($targetGame, "SkyrimSE", "SkyrimVR", "Skyrim")
$skseNames        = @("skse64_loader", "skse_loader", "skse64_loader")
$gameLabels = @{
    "SkyrimSE" = "Skyrim Special Edition"
    "SkyrimVR" = "Skyrim VR"
    "Skyrim"   = "Skyrim Legendary Edition"
}

# ==================================================
#  LANCEMENT SKYRIM
# ==================================================
Spin (T "Lancement de Skyrim via SKSE..." "Launching Skyrim via SKSE..." "Skyrim wird gestartet..." "Iniciando Skyrim via SKSE...")

# Tente de lancer skse64_loader en priorite, sinon skse_loader
$skseExe = $null
foreach($loader in @("skse64_loader.exe","skse_loader.exe")) {
    if(Test-Path "$PSScriptRoot\$loader") { $skseExe = $loader; break }
}
if($skseExe) {
    Start-Process "$PSScriptRoot\$skseExe"
    Log "ACTION" "$skseExe launched"
} else {
    WC (T "[ERREUR] Aucun loader SKSE trouve." "[ERROR] No SKSE loader found." "Kein SKSE-Loader gefunden." "No se encontro el loader SKSE.") Red
    Log "ERROR" "No SKSE loader found"
    exit
}

WC (T "En attente de Skyrim (max 30s)..." "Waiting for Skyrim (max 30s)..." "Warte auf Skyrim (max 30s)..." "Esperando Skyrim (max 30s)...") DarkYellow

# Cherche le processus Skyrim (toutes versions)
$p=$null; $detectedGame=$null; $timeout=30; $elapsed=0
while(-not $p -and $elapsed -lt $timeout){
    Start-Sleep -Seconds 1; $elapsed++
    foreach($name in $gameProcessNames){
        $p = Get-Process -Name $name -ErrorAction SilentlyContinue
        if($p){ $detectedGame = $name; break }
    }
}

if(-not $p){
    WC (T "[ERREUR] Aucun processus Skyrim trouve apres $timeout s." "[ERROR] No Skyrim process found after $timeout s." "Kein Skyrim-Prozess gefunden nach $timeout s." "No se encontro proceso Skyrim tras $timeout s.") Red
    Log "ERROR" "No Skyrim process found after $timeout s"
    exit
}

$gameLabel = if($gameLabels.ContainsKey($detectedGame)) { $gameLabels[$detectedGame] } else { $detectedGame }
Log "INFO" "$gameLabel detected PID:$($p.Id) after ${elapsed}s"

# ==================================================
#  APPLICATION AFFINITE + PRIORITE CPU
# ==================================================
Spin (T "Application du masque d'affinite..." "Applying affinity mask..." "Affinitaetsmaske wird angewendet..." "Aplicando mascara de afinidad...")
$ok = $false
for($t=1; $t -le 10; $t++){
    $p = Get-Process -Name $detectedGame -ErrorAction SilentlyContinue
    if(-not $p){ Start-Sleep -Seconds 1; continue }

    try{
        # Affinite : cores physiques uniquement
        $p.ProcessorAffinity = [IntPtr]$aml
        # Priorite : AboveNormal pour reduire les micro-stutters
        $p.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::AboveNormal
    } catch{}

    Start-Sleep -Milliseconds 700
    $p = Get-Process -Name $detectedGame -ErrorAction SilentlyContinue
    if(-not $p){ Start-Sleep -Seconds 1; continue }

    if($p.ProcessorAffinity.ToInt64() -eq $aml){
        $ok = $true
        Log "OK" "Affinity+Priority confirmed | Game:$gameLabel PID:$($p.Id) Mask:0x$hex Priority:AboveNormal Try:$t"
        break
    }
    Log "RETRY" "Attempt $t/10"
    Start-Sleep -Seconds 2
}

# ==================================================
#  RESULTAT FINAL
# ==================================================
Write-Host $sep -ForegroundColor DarkYellow
if($ok){
    WC (T "Optimisation reussie.  Have Fun ! ;-)" "Optimization complete.  Have Fun ! ;-)" "Optimierung abgeschlossen.  Viel Spass ! ;-)" "Optimizacion completa.  Disfruta ! ;-)") Green
} else {
    WC (T "[AVERT.] Non confirmee apres 10 tentatives." "[WARN.] Not confirmed after 10 attempts." "[WARN.] Nach 10 Versuchen nicht bestaetigt." "[AVISO.] No confirmado tras 10 intentos.") Yellow
}
Log "END" "Done $(Get-Date -Format 'HH:mm:ss')"
